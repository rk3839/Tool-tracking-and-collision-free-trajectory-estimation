"""
Robot Class

Author: Yasim Ahmad(yaaximus)

Email: yasim.ahmed63@yahoo.com
"""
import math as ma
import numpy as np
from utils.positional import Position


class Robot(object):
    """
    This class encorporates the capability of defining Robot object.
    """

    def __init__(self, Position, sensor_range=2.0, num_of_artif_pts=60):
        """
        This is the constructor of Robot class

        Parameters
        ----------
        Position : [Position]
            [Position of object], by default is 1.0 in both x and y axis
        sensor_range : float, optional
            [Distance from robot centre where artificial points will be defined], by default 2.0
        num_of_artif_pts : int, optional
            [Number of artificial points], by default 60
        """

        self.position = Position
        self.__sensor_range = sensor_range
        self.__step_size = 0.03*self.__sensor_range
        self.__num_of_artif_pts = num_of_artif_pts
        self.__step_degree = 360.0/self.__num_of_artif_pts
        self.__artif_pts_x = np.zeros((1, self.__num_of_artif_pts))
        self.__artif_pts_y = np.zeros((1, self.__num_of_artif_pts))
        self.__theta = np.zeros((1, self.__num_of_artif_pts))
        self.__update_theta()
        self.__artif_pts_cost_obst = np.zeros((1, self.__num_of_artif_pts))
        self.__artif_pts_cost_goal = np.zeros((1, self.__num_of_artif_pts))
        self.__artif_pts_cost = np.zeros((1, self.__num_of_artif_pts))
        self.__dist_to_goal_artif_pts = np.zeros((1, self.__num_of_artif_pts))
        self.__err_cost_func = np.zeros((1, self.__num_of_artif_pts))
        self.__err_dist_to_goal = np.zeros((1, self.__num_of_artif_pts))
        self.__fitness = np.zeros((1, self.__num_of_artif_pts))

    def __update_theta(self):
        """
        This function is used for computing angle theta's which are responsible for 
        finding x and y position of artif points x = xprev + cos(theta),
        y = yprev + sin(theta).
        """

        self.__theta[0][0] = self.__step_degree

        for num in range(1, self.__num_of_artif_pts):
            self.__theta[0][num] = self.__theta[0][num-1] + self.__step_degree

    def __cost_function_for_goal(self, goal, pt_x=None, pt_y=None):
        """Quadratic Attractive Potential Function"""
        k_att = 1.5  # Attraction coefficient
        if pt_x is None:
            d_goal = self.position.calculate_distance(goal)
        else:
            d_goal = self.position.calculate_distance(goal, x=pt_x, y=pt_y)
        
        return 0.5 * k_att * d_goal**2  # Quadratic attraction

    def __cost_function_for_obstacles(self, obstacles, pt_x=None, pt_y=None):
        """Quadratic Repulsive Potential Function"""
        k_rep = 15.0  # Strong repulsion coefficient
        d0 = 2.5  # Effective repulsion range

        cost_obst = 0.0
        if pt_x is None:
            for obstacle in obstacles:
                d_obs = self.position.calculate_distance(obstacle)
                if d_obs <= d0:
                    cost_obst += 0.5 * k_rep * ((1 / d_obs) - (1 / d0))**2
        else:
            for obstacle in obstacles:
                d_obs = self.position.calculate_distance(obstacle, x=pt_x, y=pt_y)
                if d_obs <= d0:
                    cost_obst += 0.5 * k_rep * ((1 / d_obs) - (1 / d0))**2
        return cost_obst

    def cost_function(self, goal, obstacles, pt_x=None, pt_y=None):
        """Computes the total potential cost"""
        cost_goal = self.__cost_function_for_goal(goal, pt_x, pt_y)
        cost_obst = self.__cost_function_for_obstacles(obstacles, pt_x, pt_y)
        
        print(f"Goal Cost: {cost_goal:.2f}, Obstacle Cost: {cost_obst:.2f}")  # Debugging

        return cost_goal + cost_obst

    def __update_artif_pts_coords(self):
        """Updates artificial points around the robot for movement evaluation."""
        for num in range(self.__num_of_artif_pts):
            self.__artif_pts_x[0][num] = self.position.x + \
                (self.__step_size * ma.cos(ma.pi * self.__theta[0][num] / 180.0))
            self.__artif_pts_y[0][num] = self.position.y + \
                (self.__step_size * ma.sin(ma.pi * self.__theta[0][num] / 180.0))

    def __update_artif_pts(self, goal, obstacles):
        """Updates potential values for all artificial points."""
        for num in range(self.__num_of_artif_pts):
            self.__artif_pts_cost_obst[0][num] = self.__cost_function_for_obstacles(
                obstacles=obstacles, pt_x=self.__artif_pts_x[0][num], pt_y=self.__artif_pts_y[0][num])
            self.__artif_pts_cost_goal[0][num] = self.__cost_function_for_goal(
                goal=goal, pt_x=self.__artif_pts_x[0][num], pt_y=self.__artif_pts_y[0][num])
            self.__artif_pts_cost[0][num] = self.__artif_pts_cost_obst[0][num] + \
                self.__artif_pts_cost_goal[0][num]

    def decide_next_move(self, goal, obstacles):
        """Decides the best move based on potential field evaluation."""
        self.__update_artif_pts_coords()
        self.__update_artif_pts(goal=goal, obstacles=obstacles)

    def take_next_move(self):
        """Moves the robot to the best artificial point with the lowest potential cost."""
        best_move_idx = np.argmin(self.__artif_pts_cost[0])  # Choose the best move
        self.position.x = self.__artif_pts_x[0][best_move_idx]
        self.position.y = self.__artif_pts_y[0][best_move_idx]

