import os
import sys
import subprocess
import rospy
import time
import signal

class ProgramLauncher:
    def __init__(self):
        self.programs = {
            '1': {
                'name': 'Collision APF',
                'file': 'collision.py',
                'description': 'Artificial Potential Field collision avoidance algorithm'
            },
            '2': {
                'name': 'Depth Noise',
                'file': 'depth.py',
                'description': 'Depth processing with noise handling'
            },
            '3': {
                'name': 'Exit',
                'file': None,
                'description': 'Exit the program'
            }
        }
        
        # Ensure program files exist and are executable
        self.check_files()
    
    def check_files(self):
        """Check if program files exist and are executable"""
        for key, program in self.programs.items():
            if program['file'] is not None:
                # Check if file exists
                if not os.path.isfile(program['file']):
                    print(f"Warning: {program['file']} not found in current directory")
                
                # Make sure file is executable
                try:
                    if os.path.isfile(program['file']):
                        os.chmod(program['file'], 0o755)  # rwx r-x r-x permissions
                except Exception as e:
                    print(f"Warning: Could not set executable permission on {program['file']}: {e}")
    
    def display_menu(self):
        """Display the selection menu"""
        print("\n" + "="*60)
        print("ROS Program Launcher".center(60))
        print("="*60)
        
        for key, program in self.programs.items():
            print(f"[{key}] {program['name']:<15} - {program['description']}")
        
        print("="*60)
        
    def run_program(self, program_key):
        """Run the selected program"""
        if program_key not in self.programs:
            print(f"Invalid selection: {program_key}")
            return False
            
        program = self.programs[program_key]
        
        if program['file'] is None:  # Exit option
            print("Exiting...")
            return False
            
        print(f"\nStarting {program['name']}...")
        
        try:
            # Initialize ROS node for this launcher
            if not rospy.core.is_initialized():
                rospy.init_node('program_launcher', anonymous=True)
                
            # Full path to program
            program_path = os.path.join(os.getcwd(), program['file'])
            
            # Execute the program as a subprocess
            process = subprocess.Popen(['python3', program_path])
            
            print(f"{program['name']} is running. Press Ctrl+C to stop and return to menu.")
            
            # Wait for process to complete or be interrupted
            try:
                process.wait()
            except KeyboardInterrupt:
                print(f"\nStopping {program['name']}...")
                # Send SIGINT to the process group
                os.killpg(os.getpgid(process.pid), signal.SIGINT)
                time.sleep(1)  # Give the process time to clean up
                
                # If still running, terminate more forcefully
                if process.poll() is None:
                    process.terminate()
                    time.sleep(0.5)
                    
                    # If still running after terminate, kill
                    if process.poll() is None:
                        process.kill()
            
            print(f"{program['name']} stopped.")
            return True
            
        except Exception as e:
            print(f"Error running {program['file']}: {e}")
            return True
    
    def main_loop(self):
        """Main program loop"""
        running = True
        while running:
            self.display_menu()
            choice = input("Select a program to run [1-3]: ")
            
            if choice == '3':  # Exit option
                running = False
            else:
                running = self.run_program(choice)

def main():
    launcher = ProgramLauncher()
    try:
        launcher.main_loop()
    except KeyboardInterrupt:
        print("\nProgram terminated by user.")
    except Exception as e:
        print(f"Unexpected error: {e}")
    finally:
        # Ensure ROS node is shutdown properly
        if rospy.core.is_initialized():
            rospy.signal_shutdown("Program terminated")
        print("Goodbye!")

if __name__ == '__main__':
    main()