#!/usr/bin/env python3

from control_msgs.msg import FollowJointTrajectoryAction, FollowJointTrajectoryGoal
import roslib;roslib.load_manifest('sr1')
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Float64
import actionlib
import rospy
import time

class Manipulator:
    def __init__(self, robot_group):
        self.robot_group = robot_group
        self.jta = actionlib.SimpleActionClient('/'+self.robot_group+'_controller/follow_joint_trajectory', FollowJointTrajectoryAction)
        rospy.loginfo('Waiting for joint trajectory action...')
        self.jta.wait_for_server()
        rospy.loginfo('Found joint trajectory action!!!')


    def move_joint(self, angles):
        goal = FollowJointTrajectoryGoal()
        # manipulator joint names
        goal.trajectory.joint_names = ['psm_l1_joint', 'psm_l2_joint', 'psm_l3_joint', 'psm_l4_joint', 'psm_l5_joint', 'psm_l6_joint', 'psm_l7_joint', 'psm_l8_joint', 'psm_l9_joint', 'psm_l10_joint', 'psm_l11_joint', 'psm_l12_joint', 'ecm_l1_joint', 'ecm_l2_joint', 'ecm_l3_joint', 'ecm_l4_joint', 'ecm_l5_joint', 'ecm_l6_joint', 'ecm_l7_joint', 'ecm_l8_joint', 'ecm_l9_joint']
        point = JointTrajectoryPoint()
        point.positions = angles
        point.time_from_start = rospy.Duration(3)
        goal.trajectory.points.append(point)
        self.jta.send_goal_and_wait(goal)

class Gripper(Manipulator):

    def move_joint(self, angles):
        goal = FollowJointTrajectoryGoal()
        # gripper joint names
        goal.trajectory.joint_names = ['psm_lf1_joint', 'psm_lf2_joint']
        point = JointTrajectoryPoint()
        point.positions = angles
        point.time_from_start = rospy.Duration(3)
        goal.trajectory.points.append(point)
        self.jta.send_goal_and_wait(goal)
 
def main():
    rospy.loginfo('Task started !!!')
    
    arm = Manipulator('arm') # define arm object to control manipulator
    hand = Gripper('hand') # define hand object to control gripper

    time.sleep(1)
    arm.move_joint([0.31,0.59,0.23,0.0,0.2,0.0,0.0,0.0,-0.024,-0.122,0.9,-0.4,1.25,-1.35,-0.82,0.2,0.0,-0.1,0.02,-0.1,0.8])
    hand.move_joint([-0.6,0.6])
    time.sleep(1)
    arm.move_joint([0.31,0.52,0.23,0.0,0.2,0.0,0.0,0.0,-0.024,-0.122,0.9,-0.4,1.25,-1.35,-0.82,0.2,0.0,-0.1,0.02,-0.11,0.8])
    time.sleep(1)
    arm.move_joint([0.31,0.52,0.23,0.0,0.2,0.0,0.0,0.0,-0.01,-0.12,-2.2,-0.4,1.25,-1.35,-0.82,0.2,0.0,-0.1,0.02,-0.12,0.8])
    time.sleep(1)
    arm.move_joint([0.31,0.51,0.23,0.0,0.2,0.0,0.0,0.0,-0.01,-0.12,-2.2,-0.4,1.25,-1.35,-0.82,0.2,0.0,-0.1,0.02,-0.12,0.8])
    time.sleep(0.5)
    arm.move_joint([0.31,0.508,0.23,0.0,0.2,0.0,0.0,0.0,-0.01,-0.12,-2.2,-0.4,1.25,-1.35,-0.82,0.2,0.0,-0.1,0.02,-0.12,0.8])
    time.sleep(1)
    hand.move_joint([-0.45,-0.1])
    time.sleep(0.5)
    hand.move_joint([-0.35,-0.25])
    time.sleep(1)
    arm.move_joint([0.31,0.508,0.23,0.0,0.2,0.0,0.0,0.0,-0.01,-0.108,-2.2,-0.4,1.25,-1.35,-0.82,0.2,0.0,-0.1,0.02,-0.13,0.8])
    time.sleep(1)
    arm.move_joint([0.31,0.508,0.23,0.0,0.2,0.0,0.0,0.0,-0.01,-0.108,-1.2,-0.4,1.25,-1.35,-0.82,0.2,0.0,-0.1,0.02,-0.13,0.8])
    time.sleep(1)
    arm.move_joint([0.31,0.508,0.23,0.0,0.2,0.0,0.0,0.0,-0.01,-0.108,-1.2,-0.8,1.25,-1.35,-0.82,0.2,0.0,-0.1,0.02,-0.13,0.8])
    time.sleep(1)

    rospy.loginfo('Task finished!!!')

if __name__ == '__main__':
      rospy.init_node('sr1')
      main()
