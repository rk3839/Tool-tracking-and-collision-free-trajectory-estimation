#!/usr/bin/env python3

import sys
import message_filters ### ADD THIS
import rospy
import numpy as np
import math
from std_msgs.msg import String
from sensor_msgs.msg import Image
from kalmanfilter import KalmanFilter
from cv_bridge import CvBridge, CvBridgeError
import cv2
import imutils
import time
seconds = time.time()
from ultralytics import YOLO

from Robot_1 import Robot
from Object import Object
import matplotlib.pyplot as plt
from utils.positional import Position

import sys
kf = KalmanFilter()


model = YOLO("/home/robotsim/environments/runs/segment/train96/weights/best.pt")

#------Start of Class
class image_converter:

    def __init__(self):
        self.bridge = CvBridge()

        self.depth = message_filters.Subscriber('/camera_link/depth/image_raw', Image)
        self.color = message_filters.Subscriber('/camera_link/color/image_raw', Image)
    
    

    def callback(self,rgb,depth):
        cv_image_rgb = self.bridge.imgmsg_to_cv2(rgb, "bgr8")
        
        rows, cols, _ = cv_image_rgb.shape
        x_medium = int(cols / 2)
        y_medium = int(rows / 2)
        center = int(cols / 2)

        results = model(cv_image_rgb, save=True)
        annotated_frame = results[0].plot()
        frame1 = annotated_frame.copy()

        # hsv_tis = cv2.cvtColor(frame1, cv2.COLOR_BGR2HSV)
        # lower_red = np.array([161, 155, 84])
        # upper_red = np.array([179, 255, 255])
        # red_mask = cv2.inRange(hsv_tis, lower_red, upper_red)
        # cnts_red=cv2.findContours(red_mask, cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        # cnts_red=imutils.grab_contours(cnts_red)
        # cnts_red = sorted(cnts_red, key=lambda x2:cv2.contourArea(x2), reverse=True)
        # masked_red = cv2.bitwise_and(frame1, frame1, mask = red_mask)

        # for c_red in cnts_red:
        #     (x_red, y_red, w_red, h_red) = cv2.boundingRect(c_red)
        #     x_medium_tis = int((x_red + x_red + w_red) / 2)
        #     y_medium_tis = int((y_red + y_red + h_red) / 2)

        #     area_red=cv2.contourArea(c_red)
        #     if area_red > 5:
        #         Ma=cv2.moments(c_red)
        #         sx=int(Ma["m10"]/Ma["m00"])
        #         sy=int(Ma["m01"]/Ma["m00"])
        #         #cv.drawContours(image,[c2],-1,(255,0,255), 2)
        #         #cv.rectangle(image,(x_2,y_2),(x_2+w_2,y_2+h_2),(200,255,155),2)
        #         cv2.putText(frame1, "internal  tissue",(sx, sy), cv2.FONT_HERSHEY_SIMPLEX,0.75, (0, 0, 0), 2)

        hsv = cv2.cvtColor(frame1, cv2.COLOR_BGR2HSV)
        lower_blue = np.array([75, 180, 75]) #94, 80, 2
        upper_blue = np.array([110, 255, 255]) #126, 255, 255
        blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
        cnts_blue=cv2.findContours(blue_mask, cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        cnts_blue=imutils.grab_contours(cnts_blue)
        cnts_blue = sorted(cnts_blue, key=lambda x:cv2.contourArea(x), reverse=True)
        masked_blue = cv2.bitwise_and(frame1, frame1, mask = blue_mask)

        h, w = frame1.shape[:2]
        RESIZE = (w//2, h//2)

        for c_blue in cnts_blue:
            (x, y, w, h) = cv2.boundingRect(c_blue)
            x_medium = int((x + x + w) / 2)
            y_medium = int((y + y + h) / 2)

            area2=cv2.contourArea(c_blue)
            if area2 > 5:
                try:
                    predicted = kf.predict(x_medium, y_medium)
                    
                    cv2.circle(frame1, (predicted[0], predicted[1]), 12, (255, 255, 0), 2)
                    pts=np.array([[x_medium,y_medium],[predicted[0],predicted[1]]],np.int32)
                    cv2.polylines(frame1,[pts],True,(0,255,255),3)
                except:
                    pass

                # def main():
                """
                This is the function for instantiating object of Robot, Goal, and Obstacles.
                This programs runs until distance of robot is less then 0.9 to goal and 
                during this process it keeps on deciding next move and then exectuing it.
                """

                iteration_no = 1.0
                x_limit = 16.0	#20.0	default
                y_limit = 12.0	#20.0	default

                
                # obstacle1 = Object(Position(x=2.75, y=1.0), sigma=1.0)	#scene-4
                # obstacle2 = Object(Position(x=4.0, y=2.0), sigma=1.0)	#scene-4
                # obstacle3= Object(Position(x=2.75, y=2.75), sigma=1.0)	#scene-4
                # obstacle4 = Object(Position(x=10.0, y=4.75), sigma=1.0)	#scene-4
                # obstacle5 = Object(Position(x=10.5, y=6.0), sigma=1.0)	#scene-4
                # obstacle6 = Object(Position(x=10.75, y=7.5), sigma=1.0)	#scene-4
                
                obstacle1 = Object(Position(x=8.73, y=6.08), sigma=1.0)	#scene-2    # it was scene 4
                obstacle2 = Object(Position(x=10.58, y=5.75), sigma=1.0)	#scene-2    # it was scene 4
                # obstacle1 = Object(Position(x=3.30, y=8.46), sigma=1.0)	#scene-1    # it was scene 1
                # obstacle1 = Object(Position(x=3.30, y=8.25), sigma=1.0)	#scene-3
                # obstacle2 = Object(Position(x=3.49, y=9.5), sigma=1.0)	#scene-3
                # obstacle3 = Object(Position(x=10.0, y=6.0), sigma=1.0)	#scene-3
                # obstacle4 = Object(Position(x=10.0, y=4.6), sigma=1.0)	#scene-3
                #obstacle3 = Object(Position(x=14.0, y=15.0), sigma=1.0)
                #obstacle4 = Object(Position(x=14.0, y=18.0), sigma=1.0)
                obstacles = [obstacle1, obstacle2]	# , obstacle3, obstacle4, obstacle5, obstacle6
                
                x_p_c = (x_medium*0.0264583333)
                y_p_c = ((y_medium*0.0264583333))
                x_1=("{:.1f}".format(x_p_c))
                y_1=("{:.1f}".format(y_p_c))
                robot = Robot(Position(x=float(x_1), y=float(y_1)),
                            sensor_range=2.0, num_of_artif_pts=60)
                
                goal = Object(Position(x=7.14, y=5.02), sigma=2.0)  #scene-2
                # goal = Object(Position(x=1.15, y=1.5), sigma=2.0)	#scene-4
                # robot = Robot(Position(x=11.40, y=7.27),
                #              sensor_range=2.0, num_of_artif_pts=60)
                # goal = Object(Position(x=1.71, y=9.54), sigma=2.0)	#scene-1,3
                # robot = Robot(Position(x=5.22, y=7.54),
                #             sensor_range=2.0, num_of_artif_pts=60)

                # plt.figure()
                # plt.axis([0.0, x_limit, 0.0, y_limit])
                
                # mpciter = 0
                # start_time = time.time()
                # index_t = []
                while robot.position.calculate_distance(other=goal) > 0.35:

                    # t_ = time.time()
                    # plt.plot(robot.position.x, robot.position.y,
                    #         "bo", markersize=x_limit/1.5)
                    # plt.plot(goal.position.x, goal.position.y, "go",
                    #         markersize=x_limit*goal.get_sigma())
                    # plt.plot(obstacle1.position.x, obstacle1.position.y,
                    #         "ro", markersize=x_limit*obstacle1.get_sigma())
                    #plt.plot(obstacle2.position.x, obstacle2.position.y,
                    #         "ro", markersize=x_limit*obstacle2.get_sigma())
                    #plt.plot(obstacle3.position.x, obstacle3.position.y,
                    #         "ro", markersize=x_limit*obstacle3.get_sigma())
                    #plt.plot(obstacle4.position.x, obstacle4.position.y,
                    #         "ro", markersize=x_limit*obstacle4.get_sigma())
                    # mpciter = mpciter + 1
                    # print(robot.position.x, robot.position.y)
                    #print((time.time() - start_time)/(mpciter))

                    # plt.legend(('Robot', 'Goal', 'Obstacle'), loc='lower right',
                    #         fontsize='small', numpoints=1, markerscale=0.5, labelspacing=1)

                    robot.decide_next_move(goal=goal, obstacles=obstacles)
                    robot.take_next_move()
                    # plt.draw()
                    # plt.savefig("./docs/images_for_gif/"+str(iteration_no)+".png")
                    iteration_no += 1.0
                    # plt.pause(0.02)

                    cv2.circle(frame1, (int((goal.position.x)/0.0264583333), int((goal.position.y)/0.0264583333)), 15, (0, 255, 0), 2)
                    
                    # cv2.circle(frame1, (int(((obstacle1.position.x)/0.0264583333)), int(((obstacle1.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_1
                    # cv2.circle(frame1, (int(((obstacle1.position.x)/0.0264583333)), int(((obstacle1.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_3
                    # cv2.circle(frame1, (int(((obstacle2.position.x)/0.0264583333)), int(((obstacle2.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_3
                    # cv2.circle(frame1, (int(((obstacle3.position.x)/0.0264583333)), int(((obstacle3.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_3
                    # cv2.circle(frame1, (int(((obstacle4.position.x)/0.0264583333)), int(((obstacle4.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_3
                    # cv2.circle(frame1, (int(((obstacle1.position.x)/0.0264583333)), int(((obstacle1.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_4
                    # cv2.circle(frame1, (int(((obstacle2.position.x)/0.0264583333)), int(((obstacle2.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_4
                    # cv2.circle(frame1, (int(((obstacle3.position.x)/0.0264583333)), int(((obstacle3.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_4
                    # cv2.circle(frame1, (int(((obstacle4.position.x)/0.0264583333)), int(((obstacle4.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_4
                    # cv2.circle(frame1, (int(((obstacle5.position.x)/0.0264583333)), int(((obstacle5.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_4
                    # cv2.circle(frame1, (int(((obstacle6.position.x)/0.0264583333)), int(((obstacle6.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_4
                    # cv2.circle(frame1, (int(((obstacle1.position.x)/0.0264583333)+25), int(((obstacle1.position.y)/0.0264583333))+15), 20, (255, 0, 0), -1)#scene_3
                    # cv2.circle(frame1, (int(((obstacle1.position.x)/0.0264583333)+50), int(((obstacle1.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_3
                    cv2.circle(frame1, (int(((obstacle2.position.x)/0.0264583333)), int(((obstacle2.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_2
                    cv2.circle(frame1, (int(((obstacle1.position.x)/0.0264583333)), int(((obstacle1.position.y)/0.0264583333))), 20, (255, 0, 0), -1)#scene_2

                    cv2.circle(frame1, (int((robot.position.x)/0.0264583333), int((robot.position.y)/0.0264583333)), 2, (0, 0, 255), -1)

                [vx,vy,x_0,y_0] = cv2.fitLine(c_blue, cv2.DIST_L2,0,0.01,0.01)
                lefty = int((-x_0*vy/vx) + y_0)
                righty = int(((w-x_0)*vy/vx)+y_0)

                x_axis      = np.array([0, 1])    # unit vector in the same direction as the x axis
                your_line   = np.array([vx, vy])  # unit vector in the same direction as your line
                dot_product = np.dot(x_axis, your_line)
                angle_2_x   = math.acos(dot_product)    # np.arccos(dot_product)
                angle_3_x = (angle_2_x*(180/np.pi))
                angle_4_x = str(angle_3_x)
                # ang_ref = (-5)
                # e_power = math.exp(ang_ref)
                # roll = (((-6*e_power*(angle_3_x)**2))+(0.928*angle_3_x)+0.927)            #both roll are same
                # roll = (((-0.04042769819945*(angle_3_x)**2))+(0.928*angle_3_x)+0.927)     #both roll are same
                roll=("{:.1f}".format(angle_3_x))
                rotation = str(roll)

                # cv2.line(frame1,(w-1,righty),(0,lefty),(0,255,255),2) # cross line (fit line)
                # cv2.ellipse(frame1, (x_medium, y_medium), (50,50), -angle_3_x, 60, 120, (255,0,0),-2)
                # cv2.drawContours(frame1, [c_blue], -1, (0,255,255), 2)
                M=cv2.moments(c_blue)
                cx=int(M["m10"]/M["m00"])
                cy=int(M["m01"]/M["m00"])
                rel_x = (cx-50)
                rel_y = (cy-50)
                # cv2.circle(frame1, (cx, cy), 5, (0, 0, 255), -1)
                # cv2.putText(frame1, "needle",(cx-10, cy-10), cv2.FONT_HERSHEY_SIMPLEX,1.25, (255, 255, 0), 2)
                
                # virtual output illustration
                # cv2.line(frame1, (x_medium, 0), (x_medium, 480), (0, 255, 0), 2)
                # cv2.line(frame1, (0, y_medium), (660, y_medium), (0, 255, 0), 2)
                # cv2.line(frame1, (cx, cy), (50, 50), (0, 255, 255), 2)
                

                x_cm = (x_medium*0.0264583333)
                y_cm = (y_medium*0.0264583333)

                x_cm = (((-0.0212)*(x_cm)**2)+(1.4414*x_cm)-0.3332)
                y_cm = (((-0.1384)*(y_cm)**2)+(2.1458*(y_cm))-1.1272)
                x_cm=("{:.1f}".format(x_cm))
                y_cm=("{:.1f}".format(y_cm))

                font=cv2.FONT_HERSHEY_PLAIN
                # cv2.putText(frame1,"X-axis: {}cm".format(x_cm),(460,390),font,1.0,(0, 0, 0),2,cv2.LINE_AA)
                # cv2.putText(frame1,"Y-axis: {}cm".format(y_cm),(460,410),font,1.0,(0, 0, 0),2,cv2.LINE_AA)
                # cv2.putText(frame1,"Angle: {}degree".format(rotation),(460,470),font,1.0,(0, 0, 0),2,cv2.LINE_AA)

                location = (x_medium, y_medium)
                
        try:
            cv_image_depth = self.bridge.imgmsg_to_cv2(depth, "32FC1")
            depth_array = np.array(cv_image_depth, dtype=np.float32)
            center_idx = np.array(depth_array.shape) // 2
            # print ('center depth:', depth_array[center_idx[0], center_idx[1]])
            depth_cm = (((depth_array[location[0], location[1]])/1)*100)
            z_cm = (((0.0729)*(depth_cm)**2)-(4.8018*(depth_cm))+71.104)
            z_cm=("{:.1f}".format(z_cm))
            # cv2.putText(frame1,"Z-axis: {}cm".format(z_cm),(460,430),font,1.0,(0, 0, 0),2,cv2.LINE_AA)
            print ('center depth:', depth_cm)
            cv2.imshow("Depth_Sub", cv_image_depth)
        except CvBridgeError as e:
            print (e)
        last_time = int((((time.time())-seconds)%60)-5)
        dist = (np.sqrt((rel_x**2)+(rel_y**2)+(((22.62-depth_cm)/0.0264583333)**2)))
        dist_cm = (dist*0.0264583333)
        rel_dist = (((-0.0527)*(dist_cm)**2)+(1.921*dist_cm)+0.0631)
        rel_cm=("{:.1f}".format(rel_dist))
        print("x: {}".format (x_cm), "y: {}".format (y_cm), "roll: {}".format (rotation),  "rel_dist: {}".format (rel_cm),  "time: {}".format (last_time))
        time.sleep(0.1) #delay the sample rate
        # cv2.putText(frame1,"Relative distance: {}cm".format(rel_cm),(410,450),font,1.0,(0, 0, 0),2,cv2.LINE_AA)
        cv2.imshow("RGB_Sub", frame1)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            rospy.signal_shutdown('Quit')
            cv2.destroyAllWindows()

def main():
    img_cvt = image_converter()
    rospy.init_node('image_converter', anonymous=True)
    try:
        ts = message_filters.ApproximateTimeSynchronizer([img_cvt.color,img_cvt.depth],10,0.1)
        ts.registerCallback(img_cvt.callback)
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")

if __name__ == '__main__':
    main()
