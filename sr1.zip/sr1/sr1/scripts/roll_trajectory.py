
import roslib
import rosbag
import rospy
import cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from cv_bridge import CvBridgeError

BAG_PATH = '/home/robotsim/catkin_ws/src/bagfiles/roll_traj.bag'
OUTPUT_PATH = '/home/robotsim/Downloads/img/ros_img'

class ImageFromBag():

    def __init__(self, bag_path, output_path):
        self.bridge = CvBridge()

        with rosbag.Bag(bag_path) as bag:
            for idx , (topic, msg, t) in enumerate(bag.read_messages(topics=['/camera_link/color/image_raw'])):
                try:
                    cv_image = self.bridge.imgmsg_to_cv2(msg)
                    image_name = 'roll_frame_{:06d}.png'.format(idx)
                    cv2.imwrite(output_path + image_name, cv_image)
                    print("Write image: {}".format(image_name))
                except CvBridgeError as e:
                    print(e)
                

if __name__ == '__main__':
    try:
        image_from_bag = ImageFromBag(BAG_PATH, OUTPUT_PATH)
    except rospy.ROSInterruptException:
        pass