#!/usr/bin/env python3

from control_msgs.msg import FollowJointTrajectoryAction, FollowJointTrajectoryGoal
import roslib;roslib.load_manifest('sr1')
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Float64
import actionlib
import rospy
import time

class Manipulator:
    def __init__(self, robot_group):
        self.robot_group = robot_group
        self.jta = actionlib.SimpleActionClient('/'+self.robot_group+'_controller/follow_joint_trajectory', FollowJointTrajectoryAction)
        rospy.loginfo('Waiting for joint trajectory action...')
        self.jta.wait_for_server()
        rospy.loginfo('Found joint trajectory action!!!')


    def move_joint(self, angles):
        goal = FollowJointTrajectoryGoal()
        # manipulator joint names
        goal.trajectory.joint_names = ['psm_l1_joint', 'psm_l2_joint', 'psm_l3_joint', 'psm_l4_joint', 'psm_l5_joint', 'psm_l6_joint', 'psm_l7_joint', 'psm_l8_joint', 'psm_l9_joint', 'psm_l10_joint', 'psm_l11_joint', 'psm_l12_joint', 'ecm_l1_joint', 'ecm_l2_joint', 'ecm_l3_joint', 'ecm_l4_joint', 'ecm_l5_joint', 'ecm_l6_joint', 'ecm_l7_joint', 'ecm_l8_joint', 'ecm_l9_joint']
        point = JointTrajectoryPoint()
        point.positions = angles
        point.time_from_start = rospy.Duration(3)
        goal.trajectory.points.append(point)
        self.jta.send_goal_and_wait(goal)

class Gripper(Manipulator):

    def move_joint(self, angles):
        goal = FollowJointTrajectoryGoal()
        # gripper joint names
        goal.trajectory.joint_names = ['psm_lf1_joint', 'psm_lf2_joint']
        point = JointTrajectoryPoint()
        point.positions = angles
        point.time_from_start = rospy.Duration(3)
        goal.trajectory.points.append(point)
        self.jta.send_goal_and_wait(goal)
 
def main():
    rospy.loginfo('Task started !!!')
    s = 0
    arm = Manipulator('arm') # define arm object to control manipulator
    hand = Gripper('hand') # define hand object to control gripper

    arm.move_joint([-0.1,0.05,-0.1,0.0,0.0,0.0,0.0,0.0,0.0,0.0,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(1)
    arm.move_joint([-0.23,0.18,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(1)
    arm.move_joint([-0.18,0.15,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([-0.13,0.12,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([-0.02,0.03,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.02,0.01,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.08,-0.035,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.12,-0.08,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.15,-0.12,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.18,-0.15,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.20,-0.18,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.18,-0.17,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.15,-0.16,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.09,-0.12,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.05,-0.09,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([0.03,-0.09,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([-0.01,-0.04,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([-0.06,0.01,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([-0.10,0.05,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([-0.16,0.12,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    arm.move_joint([-0.19,0.15,-0.08,0.0,0.0,0.0,0.0,0.0,0.0,-0.05,-0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
    time.sleep(s)
    

    rospy.loginfo('Task finished!!!')

if __name__ == '__main__':
      rospy.init_node('sr1')
      main()
